from http.client import NOT_FOUND
from odoo import http
from odoo.http import request
from requests import post


class Elibrary(http.Controller):
    @http.route('/demande_emprunt', type="http", auth='public', website=True)
    def emprunt(self, product_id, **post):
       # Récupérer les informations du produit et du client
        client_id = request.env.user.partner_id.id

        # Récupérer les informations du produit et du client depuis les modèles correspondants
        product = http.request.env['product.template'].sudo().browse(
            int(product_id))
        if not product.exists():
            raise NOT_FOUND()

        product_name = product.name
        product_idd = product.id
        product_image = product.image_1920
        product_price = product.list_price

        client = request.env['res.partner'].browse(int(client_id))

        # Afficher les informations de l'emprunt dans une nouvelle fenêtre ou un formulaire modale
        return request.render('elibrary.emp_request', {
            'product_name': product_name,
            'product_image': product_image,
            'product_price': product_price,
            'product_id': product_idd,
            'client': client,
        })

    @http.route('/emprunt/create', type="http", methods=['POST'], auth='public', website=True, csrf=False)
    def create_emprunt(self, **kw):
        client_id = request.env.user.partner_id.id
        product_id = kw['product_id']
        date_emprunt = kw['date_emprunt']
        date_retour = kw['date_retour']
        quantite = int(kw['quantite'])

        product = http.request.env['product.template'].browse(int(product_id))
        if not product.exists():
            raise NOT_FOUND()

        product_idd = product.id
        product_name = product.name
        product_price = product.list_price
        emprunt_prix = quantite * product_price * 0.35

        # Récupérons les infos du modèle 'elibrary.emprunt'
        Emprunt = request.env['elibrary.emprunt']

        # Créons un nouvel enregistrement d'emprunt
        emprunt = Emprunt.create({
            'product_id': product_idd,
            'client_id': client_id,
            'date_emprunt': date_emprunt,
            'date_retour': date_retour,
            'quantite': quantite,
            'statut': "en_attente",
        })
        return request.render('elibrary.success', {
            'product_name': product_name,
            'product_price': product_price,
            'product_id': product_idd,
            'emprunt_price': emprunt_prix,
        })

    @http.route('/historique', type="http", auth='public', website=True)
    def emprunt(self, **post):
       # Récupérer les informations de l'emprunt et du client
        client_id = request.env.user.partner_id.id
        emprunts = http.request.env['elibrary.emprunt'].sudo().search(
            [('client_id', '=', client_id)])
        produits_empruntes = emprunts.mapped('product_id')

        # Récupérer les informations des produits
        produits = request.env['product.template'].browse(
            produits_empruntes.ids)

        # Afficher les informations de l'emprunt dans une nouvelle fenêtre ou un formulaire modale
        return request.render('elibrary.history', {'produits': produits})
