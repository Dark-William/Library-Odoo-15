# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Theme(models.Model):
    _name = 'elibrary.theme'
    _description = 'elibrary.theme'

    name = fields.Char('Name')
    description = fields.Char('Description', required=True)
#     

class Genre(models.Model):
    _name = 'elibrary.genre'
    _description = 'elibrary.genre'

    name = fields.Char('Name')
    description = fields.Char('Description', required=True)
