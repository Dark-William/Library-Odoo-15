from datetime import datetime
from xml.dom import ValidationErr

from odoo import models, fields, api, SUPERUSER_ID, _


class Emprunt(models.Model):
    _name = 'elibrary.emprunt'
    _description = 'Emprunt d\'articles'

    product_id = fields.Many2one(
        comodel_name='product.template', string='Produit', required=True)
    client_id = fields.Many2one(
        comodel_name='res.partner', string='Client', required=True)

    date_emprunt = fields.Date(
        string='Date d\'emprunt', default=fields.Date.today())
    name = fields.Char(
        string='Code', default=lambda self: _('New'))

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code(
                'elibrary.emprunt') or _('New')
        result = super(Emprunt, self).create(vals)
        return result

    date_retour = fields.Date(string='Date de retour', required=True)

    quantite = fields.Integer(string='Quantité', required=True)

    prix = fields.Float(string='Montant à payer',
                        compute="_compute_prix", store=True)

    @api.depends('product_id', 'quantite')
    def _compute_prix(self):
        for emprunt in self:
            if emprunt.product_id and emprunt.quantite:
                emprunt.prix = emprunt.product_id.list_price * emprunt.quantite * 0.35

    statut = fields.Selection(
        selection=[('en_attente', 'En attente'), ('rejete', 'Refusé'),
                   ('en_cours', 'En cours'), ('rendu', 'Rendu')],
        string='Statut', default="en_cours"
    )
    etat = fields.Selection(
        selection=[('bon', 'Bon'), ('mauvais', 'Mauvais')],
        string='État'

    )

    val_rendu = fields.Char(string="Rendu", compute="_compute_rendu")

    @api.depends('statut')
    def _compute_rendu(self):
        for emprunt in self:
            if emprunt.statut == 'rendu':
                emprunt.val_rendu = 'True'
            else:
                emprunt.val_rendu = 'False'

    @api.constrains('statut', 'etat')
    def _check_etat(self):
        for emprunt in self:
            if emprunt.statut == 'rendu' and not emprunt.etat:
                raise ValidationErr(
                    "L'état doit être renseigné lorsque le statut est 'rendu'.")

    frais = fields.Float(string='Frais à payer', readonly=True,
                         compute="_compute_frais", store=True)

    @api.depends('etat', 'product_id')
    def _compute_frais(self):
        for emprunt in self:
            if emprunt.etat == 'mauvais' and emprunt.product_id:
                emprunt.frais = 0.3 * emprunt.product_id.list_price
            else:
                emprunt.frais = 0.0

    image_product = fields.Binary(related='product_id.image_1920')


    def confirmer_emprunt(self):
        for emprunt in self:
            if emprunt.statut == 'en_attente':
                emprunt.statut = 'en_cours'

    def annuler_emprunt(self):
        for emprunt in self:
            if emprunt.statut == 'en_attente':
                emprunt.statut = 'rejete'
