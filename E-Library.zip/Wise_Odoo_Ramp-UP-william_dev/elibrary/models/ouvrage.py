from odoo import models, fields, api


class Ouvrage(models.Model):
    _description = 'elibrary.ouvrage'
    _inherit = 'product.template'

    theme_id = fields.Many2one(comodel_name='elibrary.theme',
                               string="Thème", required=True)
    genre_id = fields.Many2one(comodel_name='elibrary.genre',
                               string="Genre", required=True)
