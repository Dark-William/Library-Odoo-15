$(document).ready(function () {
    $("#modal_appearing").on('click', function () {
        $('#exampleModal').modal('show');
    });
});
