# -*- coding: utf-8 -*-
{
    'name': "elibrary",

    'summary': """
        Bibliothèque électronique""",

    'description': 'Gestion d\'une bibliothèque, et des ouvrages contenus pour une meilleure utilisation de manière électronique',
    'update_xml': [],
    'author': "William Stone",
    'website': "http://localhost:8069",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Productivity',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'product', 'sale'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/emprunt.xml',
        'views/theme.xml',
        'views/templates.xml',
        'views/ouvrage.xml',
        'views/genre.xml',
        'views/demande_emprunt.xml',
        'views/demande_emprunt2.xml',
        'views/historique.xml'
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
    'application': True,

    # 'qweb': [
    #     'static/src/xml/demande_emprunt2.xml'
    # ],

    # 'assets': {
    #     'qweb_assets': [
    #         'static/src/js/*',
    #         'static/src/css/*',
    #     ],
    # }

}
